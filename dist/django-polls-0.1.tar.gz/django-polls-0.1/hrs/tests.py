#包含测试应用各项功能的测试类和测试函数。
from django.test import TestCase

# Create your tests here.
