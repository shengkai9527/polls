from django.contrib import admin

# Register your models here.
#可以用来注册模型，让Django自动创建管理界面。