#当前应用的配置。
from django.apps import AppConfig


class HrsConfig(AppConfig):
    name = 'hrs'
