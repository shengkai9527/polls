#存放应用的数据模型，即实体类及其之间的关系（MVC/MVT中的M）。
from django.db import models

# Create your models here.
